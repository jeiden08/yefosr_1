'use client'

import { LayoutDashboard, Settings, Users, Shield, ClipboardList } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

const NAV_ITEMS = [
  {
    name: "Dashboard",
    href: "/admin",
    icon: LayoutDashboard,
  },
  {
    name: "Users",
    href: "/admin/users",
    icon: Users,
  },
  {
    name: "Roles",
    href: "/admin/roles",
    icon: Shield,
  },
  {
    name: "Audit Logs",
    href: "/admin/audit-logs",
    icon: ClipboardList,
  },
  {
    name: "Settings",
    href: "/admin/settings",
    icon: Settings,
  },
] as const

export function AdminSidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 border-r">
      <nav className="space-y-1 p-2">
        {NAV_ITEMS.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
              pathname === item.href
                ? 'bg-accent'
                : 'hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            <item.icon className="h-4 w-4" />
            {item.name}
          </Link>
        ))}
      </nav>
    </aside>
  )
}