import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PlusCircle, Edit, Eye, EyeOff } from "lucide-react"

export const revalidate = 0

async function getPrograms() {
  const supabase = createClient()
  const { data, error } = await supabase
    .from("programs")
    .select("*")
    .order("order_index", { ascending: true })

  if (error) {
    console.error("Error fetching programs:", error)
    return []
  }

  return data
}

export default async function ProgramsPage() {
  const programs = await getPrograms()

  return (
    <div className="space-y-6">
      {/* ... rest of your JSX remains the same ... */}
    </div>
  )
}