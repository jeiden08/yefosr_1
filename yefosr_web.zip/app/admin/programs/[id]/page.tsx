import { createClient } from '@/lib/supabase/server'
import ProgramForm from '@/components/admin/program-form'
import { notFound } from 'next/navigation'

export const dynamic = 'force-dynamic' // Add this line

export default async function EditProgramPage({ 
  params 
}: { 
  params: { id: string } 
}) {
  const supabase = createClient()
  
  const { data: program, error } = await supabase
    .from('programs')
    .select('*')
    .eq('id', params.id)
    .single()

  if (error || !program) {
    notFound()
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Edit Program</h1>
      <ProgramForm program={program} />
    </div>
  )
}