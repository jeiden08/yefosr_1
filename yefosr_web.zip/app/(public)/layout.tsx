import { MainNav } from "@/components/main-nav"
import { SiteFooter } from "@/components/site-footer"
import { ScrollAnimationScript } from "@/components/scroll-animation-script"
import { ScrollToTop } from "@/components/scroll-to-top"

const DEFAULT_SETTINGS = {
  navigation: {
    links: [
      { title: "Home", href: "/" },
      { title: "About", href: "/about" },
      { title: "Programs", href: "/programs" },
      { title: "Resources", href: "/resources" },
      { title: "Gallery", href: "/gallery" },
      { title: "Blog", href: "/blog" },
      { title: "Events", href: "/events" },
      { title: "Contact", href: "/contact" },
    ],
  },
  contact_info: {
    address: "Belameling Vocational Training Centre, Palorinya Refugee Settlement, Obongi District, Uganda",
    email: "yefosr@gmail.com",
    phone: ["+256 772 253 415", "+256 765 167 682", "+211 925 059 964"],
    whatsapp: "+256 772 253 415",
  },
  social_links: {
    facebook: "https://facebook.com/profile.php?id=100064325486694",
    linkedin: "https://linkedin.com/groups/13160404",
    twitter: "",
  },
} as const

export const dynamic = 'force-dynamic'

export default async function PublicLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { createClient } = await import('@/lib/supabase/server')
  const supabase = createClient()

  const settings = await fetchSettings(supabase)

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav settings={settings} />
      <main className="flex-1">{children}</main>
      <SiteFooter settings={settings} />
      <ScrollAnimationScript />
      <ScrollToTop />
    </div>
  )
}

async function fetchSettings(supabase: ReturnType<typeof createClient>) {
  try {
    const { data: siteSettings } = await supabase
      .from("site_settings")
      .select("*")
      .in("key", ["navigation", "contact_info", "social_links"])

    if (!siteSettings?.length) return DEFAULT_SETTINGS

    return siteSettings.reduce((acc, setting) => ({
      ...acc,
      [setting.key]: { ...acc[setting.key as keyof typeof acc], ...setting.value }
    }), DEFAULT_SETTINGS)
  } catch (error) {
    console.error("Error fetching settings:", error)
    return DEFAULT_SETTINGS
  }
}