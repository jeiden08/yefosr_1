import { redirect } from 'next/navigation'
import { AdminHeader } from '@/components/admin/admin-header'
import { AdminSidebar } from '@/components/admin/admin-sidebar'

export const dynamic = 'force-dynamic'
export const revalidate = 0

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { createClient } = await import('@/lib/supabase/server')
  const supabase = createClient()

  const { admin, error } = await verifyAdminSession(supabase)
  if (error) redirect('/admin/login')

  return (
    <div className="flex min-h-screen flex-col">
      <AdminHeader admin={admin} />
      <div className="flex flex-1">
        <AdminSidebar />
        <main className="flex-1 p-6 bg-muted/40">
          {children}
        </main>
      </div>
    </div>
  )
}

async function verifyAdminSession(supabase: ReturnType<typeof createClient>) {
  try {
    const { data: { session }, error: authError } = await supabase.auth.getSession()
    if (authError || !session) throw new Error("No session")

    const { data: admin, error: adminError } = await supabase
      .from('admins')
      .select('*')
      .eq('email', session.user.email)
      .single()

    if (adminError || !admin) {
      await supabase.auth.signOut()
      throw new Error("Not an admin")
    }

    return { admin, error: null }
  } catch (error) {
    return { admin: null, error }
  }
}